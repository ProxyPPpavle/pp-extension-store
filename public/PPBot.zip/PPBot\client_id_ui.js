
const input = document.getElementById('clientIdInput');
const saveBtn = document.getElementById('saveBtn');
const statusDiv = document.getElementById('status');
const infoBox = document.getElementById('infoBox');
const accTypeSpan = document.getElementById('accType');
const creditsSpan = document.getElementById('creditsCount');


// Učitaj postojeći ID
chrome.storage.local.get(['clientId'], (result) => {
    if (result.clientId) {
        input.value = result.clientId;
        checkId(result.clientId);
    }
});

// --- Lockout Logic ---
let authAttempts = 0;
let lockUntil = 0;

chrome.storage.local.get(['authAttempts', 'lockUntil'], (res) => {
    authAttempts = res.authAttempts || 0;
    lockUntil = res.lockUntil || 0;
    checkAndApplyLock();
});

function checkAndApplyLock() {
    const now = Date.now();
    if (lockUntil > now) {
        const diff = lockUntil - now;
        if (diff > 12 * 60 * 60 * 1000) {
            showStatus('Zaključano do sutra', 'error');
            saveBtn.disabled = true;
            saveBtn.textContent = 'Dnevni limit dosegnut';
            return true;
        }
        const mins = Math.ceil(diff / 60000);
        const secs = Math.ceil((diff % 60000) / 1000);
        const lockMsg = mins > 1 ? `Zaključano još ${mins}m` : `Zaključano još ${secs}s`;
        showStatus(lockMsg, 'error');
        saveBtn.disabled = true;
        saveBtn.textContent = lockMsg;
        return true;
    }
    saveBtn.disabled = false;
    saveBtn.textContent = 'Sačuvaj ID';
    return false;
}

setInterval(checkAndApplyLock, 1000);

function recordFail() {
    authAttempts++;
    let duration = 0;
    if (authAttempts >= 10) {
        const tomorrow = new Date();
        tomorrow.setHours(24, 0, 0, 0);
        lockUntil = tomorrow.getTime();
    } else if (authAttempts >= 6) {
        duration = 20 * 60 * 1000;
    } else if (authAttempts >= 4) {
        duration = 5 * 60 * 1000;
    } else if (authAttempts >= 2) {
        duration = 1 * 60 * 1000;
    }

    if (duration > 0) lockUntil = Date.now() + duration;
    chrome.storage.local.set({ authAttempts, lockUntil });
    checkAndApplyLock();
}

function resetAttempts() {
    authAttempts = 0;
    lockUntil = 0;
    chrome.storage.local.set({ authAttempts, lockUntil });
    checkAndApplyLock();
}

saveBtn.addEventListener('click', () => {
    if (checkAndApplyLock()) return;
    const id = input.value.trim();
    if (!id) {
        showStatus('Molimo unesite ID.', 'error');
        return;
    }
    checkId(id);
});



async function checkId(id) {
    if (checkAndApplyLock()) return;
    statusDiv.textContent = 'Provera...';
    input.className = '';

    try {
        const response = await fetch('https://pp-server-eight.vercel.app/check-client', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ clientId: id })
        });

        const data = await response.json();

        if (data.status === 'success') {
            resetAttempts();
            chrome.storage.local.set({ clientId: id }, () => {
                showStatus('ID proveren!', 'success');
                input.className = 'success';
                infoBox.style.display = 'block';
                accTypeSpan.textContent = data.accountType.toUpperCase();
                creditsSpan.textContent = data.credits;
            });
        } else {
            showStatus(data.message || 'Nevažeći ID.', 'error');
            input.className = 'error';
            infoBox.style.display = 'none';
            recordFail();
        }
    } catch (err) {
        showStatus('Greška u komunikaciji sa serverom.', 'error');
    }
}

function showStatus(msg, type) {
    statusDiv.textContent = msg;
    statusDiv.style.color = type === 'success' ? '#22c55e' : '#ef4444';
}
