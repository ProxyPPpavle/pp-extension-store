
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "generate_code") {
    // Proveri Client ID
    chrome.storage.local.get(['clientId'], (result) => {
      const clientId = result.clientId;

      if (!clientId) {
        sendResponse({ text: "ERROR: Nemaš podešen Client ID. Pritisni Ctrl+Shift+L da ga uneseš." });
        return;
      }

      handleServerRequest(request.prompt, clientId)
        .then(text => {
          sendResponse({ text });
        })
        .catch(err => {
          // Ako server javi da nema kredita, pošalji specifičan signal
          if (err.message.includes("kredita")) {
            sendResponse({ text: "OUT_OF_CREDITS" });
          } else {
            sendResponse({ text: "SERVER ERROR: " + err.message });
          }
        });
    });
    return true;
  }

  if (request.action === "get_credits") {
    chrome.storage.local.get(['clientId'], (result) => {
      if (!result.clientId) {
        sendResponse({ credits: 0 });
        return;
      }
      fetch("https://pp-server-eight.vercel.app/check-client", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ clientId: result.clientId })
      })
        .then(res => res.json())
        .then(data => sendResponse({ credits: data.credits || 0 }))
        .catch(() => sendResponse({ credits: 0 }));
    });
    return true;
  }
});

// Slušaj prečicu za otvaranje UI
chrome.commands.onCommand.addListener((command) => {
  if (command === "open-client-id-ui") {
    chrome.windows.create({
      url: "client_id_ui.html",
      type: "popup",
      width: 420,
      height: 520
    });
  } else if (command === "open-ai-chat") {
    // Šaljemo poruku content scriptu da otvori chat panel
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, { action: "toggle-chat" });
      }
    });
  }
});

async function handleServerRequest(userPrompt, clientId) {
  const url = "https://pp-server-eight.vercel.app/answer-questions";

  try {
    const res = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        prompt: userPrompt,
        clientId: clientId
      })
    });

    const data = await res.json();

    if (!res.ok || data.status === 'error') {
      console.error("Server Error Data:", data);
      throw new Error(data.message || `Greška ${res.status}`);
    }

    return data.answer;
  } catch (error) {
    console.error("Fetch implementation error:", error);
    throw error;
  }
}
