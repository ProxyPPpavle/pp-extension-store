let lastResponse = "";

function initPPBot() {
  if (document.getElementById("pp-trigger")) return;
  if (!document.body) {
    setTimeout(initPPBot, 100);
    return;
  }

  // Create PP button
  const trigger = document.createElement("div");
  trigger.id = "pp-trigger";
  trigger.textContent = "PP";
  document.body.appendChild(trigger);

  // Create input & copy button (hidden initially)
  const input = document.createElement("textarea");
  input.id = "pp-input";
  input.placeholder = "Type here...";
  input.spellcheck = false;
  input.style.display = "none";
  document.body.appendChild(input);
  input.style.border = "none";
  input.style.outline = "none";
  input.style.width = "50px";
  input.style.height = "15px";
  input.style.color = "rgb(255, 255, 255, 0)";

  const copyBtn = document.createElement("div");
  copyBtn.id = "pp-copy-btn";
  copyBtn.style.display = "none";
  document.body.appendChild(copyBtn);

  // Credit display (hidden initially)
  const creditBadge = document.createElement("div");
  creditBadge.id = "pp-credits-badge";
  creditBadge.style.display = "none";
  document.body.appendChild(creditBadge);

  const updateCreditsUI = () => {
    chrome.runtime.sendMessage({ action: "get_credits" }, (res) => {
      creditBadge.textContent = `⚡ AI: ${res?.credits || 0}`;
    });
  };

  // Listeners
  trigger.addEventListener("click", () => {
    const isShowing = input.style.display === "block";
    input.style.display = isShowing ? "none" : "block";
    creditBadge.style.display = isShowing ? "none" : "block";
    if (!isShowing) {
      input.focus();
      updateCreditsUI();
    }
  });

  chrome.runtime.onMessage.addListener((request) => {
    if (request.action === "toggle-chat") {
      trigger.click();
    }
  });

  input.addEventListener("keydown", (e) => {
    if (e.ctrlKey && e.key === "Enter") {
      e.preventDefault();
      sendMessage(input, copyBtn, creditBadge);
    }
    if (e.key === "Escape") {
      input.style.display = "none";
      creditBadge.style.display = "none";
    }
  });

  copyBtn.addEventListener("click", () => {
    if (!lastResponse) return;
    navigator.clipboard.writeText(lastResponse).then(() => {
      copyBtn.style.display = "none";
      input.value = "";
    });
  });
}

function sendMessage(input, copyBtn, creditBadge) {
  const text = input.value.trim();
  if (!text) return;

  input.style.display = "none";
  creditBadge.style.display = "none";

  chrome.runtime.sendMessage({ action: "generate_code", prompt: text }, (response) => {
    if (response && response.text === "OUT_OF_CREDITS") {
      lastResponse = "⚠ NEMAŠ VIŠE ENERGIJE! \n\nPritisni Ctrl+Shift+L da dopuniš kredite besplatno.";
      copyBtn.style.display = "flex";
      return;
    }

    if (response && response.text) {
      lastResponse = response.text;
      copyBtn.style.display = "flex";
    } else {
      lastResponse = response.text || "No response from AI";
      copyBtn.style.display = "flex";
    }
  });
}

// Start
initPPBot();
setTimeout(initPPBot, 2000);
