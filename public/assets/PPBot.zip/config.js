export const GROQ_API_KEY = "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";
